const mongoCollections = require("../config/mongoCollections");
const recipes = mongoCollections.recipes;
// const comments = require("./comments");
const uuid = require("uuid");

const exportedMethods = {
    async getAllRecipes() {
        const recipesCollection = await recipes();
        return await recipesCollection.find({}, { title: 1 }).toArray();
    },
    // async getRecipeByTag(tag){
    //     if (!tag)
    //         throw "No tag provided";

    //     const recipesCollection = await recipes();
    //     return await recipesCollection.find({ tags: tag}).toArray();
    // },
    async getRecipeById(id) {
        const recipesCollection = await recipes();
        const recipe = await recipesCollection.findOne({ _id: id });

        if (!recipe)
            throw "Recipe not found";
        return recipe;
    },
    async addRecipes(title, ingredients, steps) {
        console.log("inside function")
        if (typeof title !== "string" || title === "")
            throw "No title provided";

        // if (typeof body != "string")
        //     throw "I aint got nobody!";

        if (!Array.isArray(ingredients)) {
            throw "There should a name and amount for the ingredients";
        }
        if (ingredients.length <= 0) {
            throw "There should be atleast one ingredients";
        }
        for (let i = 0; i < ingredients.length; i++) {
            console.log("inside ing.")
            if (typeof ingredients[i].name !== "string" || ingredients[i].name === "")
                throw "Name should be a string";
            if (typeof ingredients[i].amount !== "string" || ingredients[i].amount === "")
                throw "Please specify the amount in correct format ex. number ingredient name";
        }


        if (!Array.isArray(steps)) {
            throw "There should at least be one step";
        }
        if (steps.length <= 0) {
            throw "There should atleast be one step for your recipe";
        }
        for (let i = 0; i < steps.length; i++) {
            console.log("inside steps")
            if (typeof steps[i] !== "string" || steps[i] === "")
                throw "You should define a proper method for making the recipe"
        }

        const recipesCollection = await recipes();

        // const commentThatPosted = await comments.getCommentByI(commentId);

        const newRecipe = {
            _id: uuid.v4(),
            title: title,
            ingredients: ingredients,
            steps: steps,
            comments: []
        };

        const newRecipeInformation = await recipesCollection.insertOne(newRecipe);
        const newId = newRecipeInformation.insertedId;
        return await this.getRecipeById(newId);
    },

    async removeRecipe(id) {
        const recipesCollection = await recipes();
        const deletionInfo = await recipesCollection.removeOne({ _id: id });
        if (deletionInfo.deletedCount === 0) {
            throw `Could not delete recipe with id of ${id}`;
        }
    },
    async updateRecipe(id, updatedRecipe) {
        const recipesCollection = await recipes();

        const updatedRecipeData = {};

        if (updatedRecipe.steps) {
            if (!Array.isArray(updatedRecipe.steps)) {
                throw "There should at least be one step";
            }
            if (updatedRecipe.steps.length <= 0) {
                throw "There should atleast be one step for your recipe";
            }
            for (let i = 0; i < updatedRecipe.steps.length; i++) {
                if (typeof updatedRecipe.steps[i] !== "string" || updatedRecipe.steps[i] === "")
                    throw "You should define a proper method for making the recipe"
            }
            updatedRecipeData.steps = updatedRecipe.steps;
        }

        if (updatedRecipe.title) {
            if (typeof updatedRecipe.title !== "string" || updatedRecipe.title === "")
                throw "No title provided";
            updatedRecipeData.title = updatedRecipe.title;
        }

        if (updatedRecipe.ingredients) {
            if (!Array.isArray(updatedRecipe.ingredients)) {
                throw "There should a name and amount for the ingredients";
            }
            if (updatedRecipe.ingredients.length <= 0) {
                throw "There should be atleast one ingredients";
            }
            for (let i = 0; i < updatedRecipe.ingredients.length; i++) {
                if (typeof updatedRecipe.ingredients[i].name !== "string" || updatedRecipe.ingredients[i].name === "")
                    throw "Name should be a string";
                if (typeof updatedRecipe.ingredients[i].amount !== "string" || updatedRecipe.ingredients[i].amount === "")
                    throw "Please specify the amount in correct format ex. number ingredient name";
            }
            updatedRecipeData.ingredients = updatedRecipe.ingredients;
        }

        let updateCommand = {
            $set: updatedRecipeData
        };
        const query = {
            _id: id
        };
        await recipesCollection.updateOne(query, updateCommand);

        return await this.getRecipeById(id);
    },

    async getCommentByRecipeId(id) {
        //console.log("Inside getcommentby recipeid");
        const recipesCollection = await recipes();
        const recipe = await recipesCollection.findOne({ _id: id });
        let commentlist = [];

        if (!recipe)
            throw "There is no such recipe";

        let recipetitle = recipe.title;
        let recipecomment = recipe.comments;
        console.log(recipecomment.length)
        console.log("1")
        for (let i = 0; i < recipecomment.length; i++) {
             console.log("2")
             list = {
                _id: recipecomment[i]._id,
                recipeId: id,
                recipetitle: recipetitle,
                poster: recipecomment[i].poster,
                comment: recipecomment[i].comment
            };
            commentlist.push(list);
        }
        return commentlist;
    },

    async getCommentById(id) {
        //console.log("inside get comment id");
        console.log("1")
        const recipesCollection = await recipes();
        const recipe = await recipesCollection.findOne({"comments._id": id});
        const recipecomments = await recipesCollection.findOne({ "comments._id": id },{"comments.$": 1, _id: 0});
        // console.log(recipe);

        if (!recipe)
            throw "There is no such recipe";
        console.log("1")
        if(!recipecomments)
            throw "There are no comments";
        console.log("2")    
        let recipeId = recipe._id;
        let recipetitle = recipe.title;
        console.log("3")
        // let recipecomment = recipe.comments;
        // console.log(recipecomment)
        // console.log(typeof recipecomment+"  "+recipecomment.length);

        // for(let i = 0; i < recipecomment.length; i++){
        //     //console.log(recipecomment[i]._id)
        //     if(recipecomment[i]._id == id){
        //         // console.log("check"+recipecomment[i].poster)
        //         // console.log(recipecomment[i].comment)
        //         let comments=recipecomment[i].comment;
        //         let posters=recipecomment[i].poster;
        //         // console.log("inside if "+comments+" "+posters)
        //          commentlist = {
        //             _id: id,
        //             recipeId: recipeId,
        //             recipetitle: recipetitle,
        //             poster: posters,
        //             comment: comments
        //         }
        //     }

        // }
        console.log(recipecomments);
        console.log("4")
        let commentlist = {
            _id: id,
            recipeId: recipeId,
            recipetitle: recipetitle,
            poster: recipecomments.comments[0].poster,
            comment: recipecomments.comments[0].comment
        }
        // console.log(commentlist);
        console.log("5")
        return commentlist;
    },

    async addComment(id, poster, comment) {

        console.log("inside add comments")
        console.log(poster);
        if (typeof poster !== "string" || poster === "")
            throw "No provided";

        if (typeof comment !== "string" || comment == "")
            throw "There are no comments";

        const recipesCollection = await recipes();

        const newComment = {
            _id: uuid.v4(),
            poster: poster,
            comment: comment
        };

        await recipesCollection.updateOne({ _id: id }, { $push: { comments: newComment } });

        return newComment;
    },

    async updateComment(recipeId, commentId, updatedComment) {
        console.log("inside update comments data ")
        const recipesCollection = await recipes();

        const updatedCommentData = {};
        if(updatedComment.poster || updatedComment.comment)
        {
            if(updatedComment.poster && updatedComment.poster)
            {
                if (typeof updatedComment.poster !== "string" || updatedComment.poster === "")
                throw "No name provided";
                if (typeof updatedComment.comment !== "string" || updatedComment.comment === "")
                throw "There are no comments to update";
                recipesCollection.updateOne(
                    {
                            _id: recipeId,
                            comments: { $elemMatch: {_id: commentId}}
                    },
                    { $set: {"comments.$.poster": updatedComment.poster, "comments.$.comment":updatedComment.comment}}
                    )


            }
            else if(!updatedComment.poster && updatedComment.comment )
            {
                recipesCollection.updateOne(
                    {
                            _id: recipeId,
                            comments: { $elemMatch: {_id: commentId}}
                    },
                    { $set: {"comments.$.comment":updatedComment.comment}}
                    )
            }
            else if(!updatedComment.comment && updatedComment.poster )
            {
                recipesCollection.updateOne(
                    {
                            _id: recipeId,
                            comments: { $elemMatch: {_id: commentId}}
                    },
                    { $set: {"comments.$.poster":updatedComment.poster}}
                    )
            }
        }
        if (updatedComment.poster) {
            console.log("inside update comments data ")
            if (typeof updatedComment.poster !== "string" || updatedComment.poster === "")
                throw "No name provided";

            await recipesCollection.updateOne(
            {
                    _id: recipeId,
                    comments: { $elemMatch: {_id: commentId}}
            },
            { $set: {"comments.$.poster": updatedComment.poster}}
            )
            updatedCommentData.poster = updatedComment.poster;
        }
        
        if (updatedComment.comment) {
            console.log("inside update comments ")
            if (typeof updatedComment.comment !== "string" || updatedComment.comment === "")
                throw "There are no comments to update";
                
            await recipesCollection.updateOne(
            {
                _id: recipeId,
                comments: { $elemMatch: {_id: commentId}}
            },
            { $set: {"comments.$.comment": updatedComment.comment}}
            )

            updatedCommentData.comment = updatedComment.comment;
        }
        console.log("after comment");
        // let updateCommand = {
        //     $set: updatedCommentData
        // };

        // const query = {
        //     _id: recipeId,
        //     "comment._id": commentId
        // };
        // console.log("ending in update")
        // await recipesCollection.updateOne({_id:recipeId,'comments._id':commentId},{ "$set": {"recipes.$.comments.0.":updatedCommand}});
        console.log(this.getCommentById(commentId));
        return await this.getCommentById(commentId);
    },

    async removeComment(id) {
        const recipesCollection = await recipes();
        const deletionInfo = await recipesCollection.update({ "comments._id": id }, { $pull: { comments: { _id: id } } });
        if (deletionInfo.deletedCount === 0) {
            throw `Could not delete recipe with id of ${id}`;
        }
    },

};

module.exports = exportedMethods;