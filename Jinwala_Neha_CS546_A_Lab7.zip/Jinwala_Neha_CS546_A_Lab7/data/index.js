const recipeData = require("./recipes");
// const commentData = require("./comments");

module.exports = {
    recipes: recipeData,
    // comments: commentData
};