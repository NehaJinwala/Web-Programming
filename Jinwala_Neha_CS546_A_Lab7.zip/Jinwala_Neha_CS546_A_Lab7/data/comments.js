const mongoCollections = require("../config/mongoCollections");
const comments = mongoCollections.comments;
const uuid = require('node-uuid');

let exportedMethods = {
    getAllComments(){
        return comments().then((commentCollection) => {
            return commentCollection.find({}).toArray();
        });
    },
    getCommentById(id){
        return comments().then((commentCollection) => {
            return commentCollection.findOne({ _id: id}).then((comment) => {
                if(!comment)
                    throw "Comments not found";
                
                return comment;
            });
        });
    },

    addComment(poster, comment){
        return comments().then((commentCollection) => {
            let newComment = {
                poster: poster,
                comment: comment,
                _id: uuid.v4(),
                recipes: []
            };

            return commentCollection.insertOne(newComment).then((newInsertInformation) => {
                return newInsertInformation,insertedId;
            }).then((newId) => {
                return this.getCommentById(newId);
            });
        });
    },
    removeComment(id){
        return comments().then((commentCollection) => {
            return commentCollection.removeOne({ _id: id}).then((deletionInfo) => {
                if(deletionInfo.deletedCount === 0){
                    throw (`Could not delete user with id of ${id}`)
                }
            });
        });
    },
    updateComment(id, updatedComment){
        return this.getCommentById(id).then((currentComment) => {
            let commentUpdateInfo = {
                poster: updatedComment.poster,
                comment: updatedComment.comment
            };

            let updateCommand = {
                $set: commentUpdateInfo
            };

            return comments().then((commentCollection) => {
                return commentCollection.updateOne({ _id: id}, updateCommand).then(() => {
                    return this.getCommentById(id);
                });
            });
        });
    },
    addCommentToRecipe(commentId, recipeId, recipeTitle){
        return this.getCommentById(id).then((currentComment) => {

            return commentCollection.updateOne({ _id: id}, {
                $addToSet: {
                    recipes: {
                        id: recipeId,
                        title: recipeTitle
                    }
                }
            });
        });
    },
    removeRecipeFromComment(commentId, recipeId){
        return this.getCommentById(id).then((currentComment) => {
            return commentCollection.updateOne({ _id: id }, {
                $pull: {
                    recipes: {
                        id: recipeId
                    }    
                }
            });
        });
    }
}

module.exports = exportedMethods;