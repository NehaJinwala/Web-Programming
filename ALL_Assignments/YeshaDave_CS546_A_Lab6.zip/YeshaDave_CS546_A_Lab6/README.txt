In order to see story: 
http://localhost:3000/story

In order to see education:
http://localhost:3000/education

In order to see about me:
http://localhost:3000/about